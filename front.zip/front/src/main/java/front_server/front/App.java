package front_server.front;

import static spark.Spark.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


//import org.apache.log4j.BasicConfigurator;

public class App {
	 static int replication_value_buy = 0;
	 static int replic_value_l_s=0;
	 static cache_in_memry cache= new cache_in_memry();
    public static void main(String[] args) {

port(8005);


 
        get("/lookup/:value", (req, res) ->{
        	//replic_value_l_s++;
            String output1 ="";
            URL url2 ;
            
           //check if request in cache
            String  data=  (String)cache.get(req.params(":value"));
           if(data != null) {
        	   return data;
           }
           else {
            
            
        	   replic_value_l_s++;
            
            
            try {
                    if(replic_value_l_s %2 == 0 ) {
                    url2 = new URL("http://192.168.43.254:8081/lookup/"+req.params(":value"));
                    
                    }
                    else {
                    	  url2 = new URL("http://192.168.43.254:8080/lookup/"+req.params(":value"));
                    }
               
               
                
                
                
                
                HttpURLConnection conn = (HttpURLConnection) url2.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");

                if (conn.getResponseCode() != 200) {
                    throw new RuntimeException("Failed : HTTP error code : "
                            + conn.getResponseCode());
                }

                BufferedReader br = new BufferedReader(new InputStreamReader(
                        (conn.getInputStream())));

                String output;
                System.out.println("Output from lookup Server .... \n");
                while ((output = br.readLine()) != null) {
                    output1+=output;
                }
                //3 minutes
                cache.add(req.params(":value"), output1, 180000);
                conn.disconnect();
             
                }
           
                
                //conn.disconnect();
             

             catch (MalformedURLException e) {

                e.printStackTrace();

            } catch (IOException e) {

                e.printStackTrace();

            }
           }
            return output1;

       });

        
        
       
        get("/buy/:value", (req, res) ->{
        	
        	replication_value_buy++;
            String output1 ="";
            URL url2;
           delete_cache(req.params("value"));
           
          
            
           
            try {
                      
            	if (replication_value_buy% 2 == 0) {
             url2 = new URL("http://192.168.56.101:8007/buy/"+req.params(":value"));
            		
            	}
            	else {
            		url2 = new URL("http://192.168.56.101:8001/buy/"+req.params(":value"));
            		
            	}
            	
                
                HttpURLConnection conn = (HttpURLConnection) url2.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");

                if (conn.getResponseCode() != 200) {
                    throw new RuntimeException("Failed : HTTP error code : "
                            + conn.getResponseCode());
                }

                BufferedReader br = new BufferedReader(new InputStreamReader(
                        (conn.getInputStream())));

                String output;
                System.out.println("Output from buy Server .... \n");
                while ((output = br.readLine()) != null) {
                    output1+=output;
                }
                conn.disconnect();
             
                }
                
                
                //conn.disconnect();
             

             catch (MalformedURLException e) {

                e.printStackTrace();

            } catch (IOException e) {

                e.printStackTrace();

            }

            return output1;

       });

        get("/search/:value" , (req,res) ->{
            String output1 ="";
           //replic_value_l_s++;
           URL url;
           String s = req.params(":value").replaceAll(" ", "%20");
           String  data=  (String)cache.get(req.params(":value"));
           if(data != null) {
        	   return data;
           }
           else {
           
        	   replic_value_l_s++;
           
           
            try {
            	if(replic_value_l_s %2 == 0) {
            		 
                      url = new URL("http://192.168.43.254:8081/search/"+s);
            	}
            	else {
            		
            		 url = new URL("http://192.168.43.254:8080/search/"+s);
            	}
            	
            	
            	
                
                HttpURLConnection conn2 = (HttpURLConnection) url.openConnection();
                     conn2.setRequestMethod("GET");
               conn2.setRequestProperty("Accept","application/json"); 
               
               if (conn2.getResponseCode() != 200 ) {
                    throw new RuntimeException("Failed : HTTP error code : "
                            + conn2.getResponseCode());
                }
                      
               BufferedReader br = new BufferedReader(new InputStreamReader(
                        (conn2.getInputStream())));

                String output;
                System.out.println("Output from search Server .... \n");
                while ((output = br.readLine()) != null) {
                    output1+=output;
                }
                cache.add(req.params(":value"), output1, 180000);
                conn2.disconnect();
             
                }
                
                
                //conn.disconnect();
             

             catch (MalformedURLException e) {

                e.printStackTrace();

            } catch (IOException e) {

                e.printStackTrace();

            }
           }
            return output1;

        });
  
    }
    
    public static void delete_cache(String id) {
    	 String  data=  (String)cache.get(id);
         String search_d1 = (String)cache.get("distributed systems");
         String search_d2 = (String)cache.get("graduate school");
        
         if(id.equals("3") || id.equals("4") || id.equals("5")) {
        	 if(search_d2 != null) {
        		 cache.remove("graduate school");
        	 }
         }
         else if (id.equals("1") || id.equals("2") || id.equals("6")|| id.equals("7")){
        	 if(search_d1 != null) {
        		 cache.remove("distributed systems");
        	 }
        	 
         }
        
       
        
    	   if(data != null) {
           	//remove lookup from cache
           	cache.remove(id);}
    	   return;
    }
   
}
