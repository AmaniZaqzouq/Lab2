package front_server.front;
import com.google.common.primitives.Longs;

import lombok.*;

 
import java.lang.ref.SoftReference;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;
public class cache_in_memry {

	private final ConcurrentHashMap<String, SoftReference<Object>> 
	cache = new ConcurrentHashMap<>();
    private final DelayQueue<DelayedCacheObject> 
    cleaningUpQueue = new DelayQueue<>();
	
	public cache_in_memry() {
		 Thread cleanerThread = new Thread(() -> {
	            while (!Thread.currentThread().isInterrupted()) {
	                try {
	                    DelayedCacheObject delayedCacheObject 
	                    = cleaningUpQueue.take();
		
	                    cache.remove(delayedCacheObject.getKey(), delayedCacheObject.getReference());
	                } catch (InterruptedException e) {
	                    Thread.currentThread().interrupt();
	                }
	            }
	        });
	        cleanerThread.setDaemon(true);
	        cleanerThread.start();
	
	}
	
	
	
	    public void add(String key, Object value, long periodInMillis) {
	        if (key == null) {
	            return;
	        }
	        if (value == null) {
	            cache.remove(key);
	        } else {
	            long expiryTime = System.currentTimeMillis() + periodInMillis;
	            SoftReference<Object> reference = new SoftReference<>(value);
	            cache.put(key, reference);
	            cleaningUpQueue.put(new DelayedCacheObject(key, reference, expiryTime));
	        }
	    }
	
	    public void remove(String key) {
	        cache.remove(key);
	    }

	   
	    public Object get(String key) {
	        return Optional.ofNullable(cache.get(key)).map(SoftReference::get).orElse(null);
	    }

	   
	    public void clear() {
	        cache.clear();
	    }

	    
	    public long size() {
	        return cache.size();
	    }

	    @AllArgsConstructor
	    @EqualsAndHashCode
	    private static class DelayedCacheObject implements Delayed {

	        @Getter
	        private final String key;
	        @Getter
	        private final SoftReference<Object> reference;
	        private final long expiryTime;

	        public DelayedCacheObject(String key2, SoftReference<Object> reference2, long expiryTime2) {
				// TODO Auto-generated constructor stub
	        	key= key2;
	        	reference=reference2;
	        	expiryTime=expiryTime2;
			}

			public Object getKey() {
				// TODO Auto-generated method stub
				return key;
			}

			public Object getReference() {
				// TODO Auto-generated method stub
				return reference;
			}

			@Override
	        public long getDelay(TimeUnit unit) {
	            return unit.convert(expiryTime - System.currentTimeMillis(), TimeUnit.MILLISECONDS);
	        }

	        @Override
	        public int compareTo(Delayed o) {
	            return Longs.compare(expiryTime, ((DelayedCacheObject) o).expiryTime);
	        }
	    }
}
