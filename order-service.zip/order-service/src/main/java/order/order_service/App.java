package order.order_service;


import static spark.Spark.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

//import org.apache.log4j.BasicConfigurator;

public class App {
	static int replic = 0;
    public static void main(String[] args) {
      //  BasicConfigurator.configure();

      port(8001);

        get("/buy/:value", (req, res) ->{
        	replic++;
            String output1 ="";
            URL url;
            try {

            	if(replic % 2 ==0 ) {
            		url = new URL("http://192.168.43.254:8081/lookup/"+req.params(":value"));
            	}
            	else {
            		
            		url = new URL("http://192.168.43.254:8080/lookup/"+req.params(":value"));
            	}
              
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");

                if (conn.getResponseCode() != 200) {
                    throw new RuntimeException("Failed : HTTP error code : "
                            + conn.getResponseCode());
                }

                BufferedReader br = new BufferedReader(new InputStreamReader(
                        (conn.getInputStream())));

                String output;
                System.out.println("Output from Server .... \n");
                while ((output = br.readLine()) != null) {
                    output1+=output;
                }
                conn.disconnect();
                if(output1.equals("book not found or error in id")) {
                	output1= "Book doesn't exist in out store";
                }
                else {
                	
                	//order server have to update both copies of database on both copies of catalog service 
                	 URL url2 = new URL("http://192.168.43.254:8080/update/"+req.params(":value"));
                     HttpURLConnection conn2 = (HttpURLConnection) url2.openConnection();
                     conn2.setRequestMethod("PUT");
                     
                     URL url3 = new URL("http://192.168.43.254:8081/update/"+req.params(":value"));
                     HttpURLConnection conn3 = (HttpURLConnection) url3.openConnection();
                     conn3.setRequestMethod("PUT");
                     
                     conn2.setRequestProperty("Accept", "application/json");
                     conn2.setDoOutput(true);
                     conn3.setRequestProperty("Accept", "application/json");
                     conn3.setDoOutput(true);

                    /* if (conn2.getResponseCode() != 200) {
                         throw new RuntimeException("Failed : HTTP error code : "
                                 + conn2.getResponseCode());
                     }*/
                     String update= "{\"quantity\":-1}";
 
                     OutputStreamWriter out = new OutputStreamWriter(
                    		    conn2.getOutputStream());
                    		out.write(update);
                    		OutputStreamWriter out1 = new OutputStreamWriter(
                        		    conn3.getOutputStream());
                        		out1.write(update);
                    		
                    		
                    		output1= "The book  "+req.params(":value")+
                    				"  is added to your pursh list.";
                    		
                    		
                    		out.close();
                    		out1.close();
                    		conn2.getInputStream();
                    		conn3.getInputStream();
                    		// conn2.disconnect();
                	
                	
                	
                	
                }
                
                
                //conn.disconnect();
             

            } catch (MalformedURLException e) {

                e.printStackTrace();

            } catch (IOException e) {

                e.printStackTrace();

            }

            return output1;

        });


        
        
        
        
        
        
        
        
        
    }
}
 
