package front_server.front;

import static spark.Spark.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

//import org.apache.log4j.BasicConfigurator;

public class App {
    public static void main(String[] args) {
      //  BasicConfigurator.configure();

port(8005);
get("/search/:val", (req1, res1) ->{
    String output1 ="";
    String s= req1.params(":val");
  String ur = "http://192.168.43.254:8080/search/"+s;
    try {

        URL url1 = new URL(ur);
        HttpURLConnection conn2 = (HttpURLConnection) url1.openConnection();
        conn2.setDoOutput(true);
        conn2.setRequestMethod("GET");
        //conn2.setRequestProperty("Accept", "application/json");
        if (conn2.getResponseCode() != 200) {
            throw new RuntimeException("Failed : HTTP error code : "
                    + conn2.getResponseCode());
        }
              
        BufferedReader br = new BufferedReader(new InputStreamReader(
                (conn2.getInputStream())));

        String output;
        StringBuffer outt = new StringBuffer();
        System.out.println("Output from front Server .... \n");
        while ((output = br.readLine()) != null) {
        	outt.append(output+"\n");
            output1+=output;
        }
        output1 = outt.toString();
        conn2.disconnect();
     
        }
        
        
        //conn.disconnect();
     

     catch (MalformedURLException e) {

        e.printStackTrace();

    } catch (IOException e) {

        e.printStackTrace();

    }

    return output1;

});

        get("/lookup/:value", (req, res) ->{
            String output1 ="";
            try {

                URL url2 = new URL("http://192.168.43.254:8080/lookup/"+req.params(":value"));
                HttpURLConnection conn = (HttpURLConnection) url2.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");

                if (conn.getResponseCode() != 200) {
                    throw new RuntimeException("Failed : HTTP error code : "
                            + conn.getResponseCode());
                }

                BufferedReader br = new BufferedReader(new InputStreamReader(
                        (conn.getInputStream())));

                String output;
                System.out.println("Output from Server .... \n");
                while ((output = br.readLine()) != null) {
                    output1+=output;
                }
                conn.disconnect();
             
                }
                
                
                //conn.disconnect();
             

             catch (MalformedURLException e) {

                e.printStackTrace();

            } catch (IOException e) {

                e.printStackTrace();

            }

            return output1;

       });

        
        
        
        get("/buy/:value", (req, res) ->{
            String output1 ="";
            try {

                URL url2 = new URL("http://192.168.56.101:8001/buy/"+req.params(":value"));
                HttpURLConnection conn = (HttpURLConnection) url2.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");

                if (conn.getResponseCode() != 200) {
                    throw new RuntimeException("Failed : HTTP error code : "
                            + conn.getResponseCode());
                }

                BufferedReader br = new BufferedReader(new InputStreamReader(
                        (conn.getInputStream())));

                String output;
                System.out.println("Output from Server .... \n");
                while ((output = br.readLine()) != null) {
                    output1+=output;
                }
                conn.disconnect();
             
                }
                
                
                //conn.disconnect();
             

             catch (MalformedURLException e) {

                e.printStackTrace();

            } catch (IOException e) {

                e.printStackTrace();

            }

            return output1;

       });

        
    }
}
